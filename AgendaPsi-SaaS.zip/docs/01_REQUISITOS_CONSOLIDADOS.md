# Requisitos consolidados — AgendaPsi (SaaS)

Atualizado: 2026-02-28

## Épico 1 — Painéis e perfis
### Funcionalidades
- Painéis: Admin / Profissional / Paciente.
- Profissional: mobile + desktop.
- Paciente: painel informativo sem CTA de cancelar/remarcar.
- Reuso: Admin e Paciente baseados no Lembrete Psi (código/UI/lógica).

### Regras de negócio
- Separação do Lembrete Psi (subdomínio e dados), mas reuso de código/UI/lógica.

### Critérios de aceitação
- Acesso ao painel correto por role.
- Paciente não vê botões/CTAs de cancelamento/remarcação.

## Épico 2 — Agenda do profissional
### Funcionalidades (MVP)
- Visões Dia/Semana/Mês.
- Navegação por granularidade.
- Reservas/Holds antes de vincular paciente.
- Agendamento com pré-cadastro rápido.
- Status manual com cor.
- Semana de aniversário destacada.
- WhatsApp com templates.

### Regras de negócio (MVP)
- Grade configurável: 30/45/60 min.
- Agendamentos/holds podem ocupar múltiplos blocos consecutivos (ex.: 2 blocos de 30 = 60 min).
- Só permite se o(s) próximo(s) horário(s) estiver(em) livre(s).
- Edição de recorrência: “só esta ocorrência” vs “esta e futuras”.

### Critérios de aceitação
- Ao criar agendamento de 2 blocos, o próximo slot fica ocupado/bloqueado.
- Alterar status aplica no grupo inteiro.

## Épico 3 — Admin (base Lembrete Psi)
### Funcionalidades (MVP)
- Reusar UI/fluxos do Admin do Lembrete Psi como base.
- Administração de tenant, usuários, profissionais, catálogos e configurações de agenda.

## Épico 4 — Paciente (base Lembrete Psi)
### Funcionalidades (MVP)
- Tela do paciente baseada no Lembrete, alimentada por ocorrências da agenda.
- Mensagens reforçando presença/constância; sem CTA de cancelar/remarcar.
