# 01 — Requisitos consolidados (AgendaPsi)

Atualizado: **2026-03-02**

## Épicos (alto nível)
1. Fundação SaaS (multi-tenant, auth, isolamento por tenant)
2. Painéis: Admin / Profissional / Paciente
3. Agenda do Profissional (Dia/Semana/Mês + regras de horários)
4. Holds/Reservas + Agendamentos + Status + Recorrência + Reagendar + Excluir
5. Cadastro de paciente (completo + pré-cadastro rápido)
6. WhatsApp e templates
7. Registros clínicos:
   - **Evolução por sessão (texto livre)**
   - **Ocorrência (registro extra com código)**
8. Hardening (Rules, LGPD operacional, auditoria mínima)
9. Relatórios (Pós-MVP): relatório por **código de ocorrência**

---

## Regras de negócio essenciais
- **Paciente**: proibido CTA de cancelar/remarcar; comunicação deve reforçar compromisso/constância.
- **Hold**:
  - `isHold=true`
  - status travado até converter
- **Edição/ações recorrentes**:
  - sempre perguntar: “Só esta ocorrência” vs “Esta e futuras”
  - operações atômicas (sem aplicar parcialmente quando houver conflito)
- **Excluir agendamento/hold**:
  - remove a utilização do horário na agenda
  - não apaga prontuário/evolução do paciente
- **Evolução por sessão**:
  - texto livre
  - vinculada ao paciente (histórico longitudinal), referenciada pela sessão (occurrenceId)
- **Ocorrência extra**:
  - registro estruturado fora do âmbito da sessão, com código + descrição

---

## Critérios de aceitação (MVP)
- Agenda Dia/Semana/Mês respeita schedule + almoço + buffer + multi-bloco.
- Recorrência cria série + materializa ocorrências com progresso `x/total`.
- Converter hold → agendamento funciona e pode estender plano.
- Reagendar e Excluir perguntam “só esta” vs “futuros”.
- Detalhe do agendamento exibe Resumo do paciente + registros (evolução + ocorrências extra).
