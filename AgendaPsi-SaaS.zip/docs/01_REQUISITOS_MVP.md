# 01 — Requisitos do MVP (AgendaPsi)

Atualizado: **2026-03-02**

## Objetivo do MVP
Entregar o fluxo completo do profissional:
- configurar agenda (Admin)
- visualizar agenda (Dia/Semana/Mês)
- criar agendamento e hold com recorrência
- reagendar e excluir (escopo: só esta vs futuras)
- registrar evolução da sessão (texto livre) e ocorrências extra (código+descrição)
- manter separação total do Lembrete Psi

---

## MVP — Itens incluídos
### Admin
- Schedule (intervalo, buffer, almoço, ranges por dia)
- Dashboard default e menus/submenus
- Catálogo de códigos de ocorrência (para “registro extra”)

### Profissional
- Dia/Semana/Mês + navegação por granularidade
- Agendar/Hold (multi-bloco, buffer) + Próximos horários (3)
- Recorrência e plano (até 30 + manual)
- Converter hold → agendamento (+ extensão)
- Reagendar (só esta vs futuras) com week picker
- Excluir (só esta vs futuras)
- Detalhe com Resumo do paciente (WhatsApp + notas)

### Registros
- Evolução por sessão (texto livre) armazenada no paciente e referenciada pelo agendamento
- Ocorrência extra (código+descrição), armazenada na ocorrência e espelhada no paciente

---

## MVP — Fora do escopo (Pós-MVP)
- Painel do paciente completo (e qualquer CTA de cancelamento/remarcação é proibido)
- Templates WhatsApp (Admin) + preenchimento automático no Profissional
- Relatórios por código de ocorrência
- Hardening completo de Rules para produção
