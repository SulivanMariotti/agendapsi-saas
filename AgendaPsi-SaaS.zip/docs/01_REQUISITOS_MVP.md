# 01 — Requisitos do MVP (AgendaPsi SaaS)

**Escopo:** MVP do AgendaPsi SaaS (produto novo, separado do Lembrete Psi).  
**Premissas:** 1 psicólogo por tenant (no MVP), SaaS com trial, foco em compromisso/constância.

---

## 1) Papéis e painéis
### 1.1 Painéis
1) **Admin (desktop) — 100% completo**  
2) **Profissional (mobile + desktop) — operação diária**  
3) **Paciente (mobile) — leitura e reforço de compromisso**

### 1.2 Restrições do paciente
- **Sem CTA de cancelar/remarcar**.
- Interações permitidas (se habilitadas): “Eu vou”, “Cheguei” (opcional, definir depois).

---

## 1.3 Reaproveitamento do Lembrete Psi (módulos e lógica)
- O **AgendaPsi SaaS** é um produto separado, porém **reaproveita o código base do Lembrete Psi** como template.
- No **Painel do Paciente**, vamos reaproveitar (com adaptações) os módulos do Lembrete Psi:
  - **diário**, **leituras/artigos** e **contrato**;
  - e a **estrutura de envio de lembretes/notificações** (FCM/Web Push), ajustada para disparar lembretes a partir dos **agendamentos/ocorrências** do AgendaPsi.
- Observação clínica obrigatória: lembretes e telas do paciente **sem CTA de cancelar/remarcar**.

---

## 2) Agenda do profissional
### 2.1 Modos de visualização
- **Dia / Semana / Mês**

### 2.2 Navegação
- Avançar/Voltar respeita o modo:
  - Dia → próximo/anterior dia
  - Semana → próxima/anterior semana
  - Mês → próximo/anterior mês

### 2.3 Slot/Cartão do agendamento (UI)
- Opções à esquerda da hora (ações rápidas).
- Exibir resumo do paciente no slot.
- Slot deve refletir cor por status.
- Marcar agendamento quando for **semana do aniversário** do paciente.

### 2.4 Próximo horário livre
- Botão “Próximo horário livre” deve encontrar o próximo slot disponível respeitando:
  - regras de funcionamento por dia
  - duração e buffer
  - almoço (se definido)
  - reservas (hold)
  - ocorrências agendadas

---

## 3) Reservas (hold)
- Criar hold em horário vago.
- Cadastro mínimo: **nome + celular**.
- Replicar reserva: até **15 dias**.
- Botão WhatsApp disponível na reserva (profissional).

---

## 4) Agendamentos recorrentes (Series + Occurrences)
### 4.1 Separação paciente x agendamento
- Cadastro do paciente é separado do agendamento.
- Agendamento referencia `patientId` (não duplicar cadastro).

### 4.2 Modelo de recorrência
- Salvar regra em **Series**
- Materializar instâncias em **Occurrences** para consulta rápida (dia/semana/mês)
- Alteração na série recalcula futuras e preserva histórico do passado.

### 4.3 Status (manual pelo profissional)
- `Agendado`
- `Confirmado`
- `Finalizado`
- `Não comparece`
- `Cancelado`
- `Reagendado`

### 4.4 Contador de sessão
- Exibir “sessão atual / total planejado”, ex.: **4/30**.
- Total planejado definido previamente no planejamento da série (campo `totalSessions`).

### 4.5 Observação + código de ocorrência
- Ocorrência permite:
  - observação (texto)
  - código selecionado de um catálogo (code + description)

### 4.6 Evolução/prontuário
- Campo de evolução por sessão.
- Tela para consultar prontuário completo do paciente (todas as sessões).

---

## 5) Edição: esta ocorrência vs futuras
Ao editar um agendamento recorrente:
- Perguntar se altera:
  - **Somente esta ocorrência**
  - **Esta e futuras a partir desta**

Regras:
- Campos por sessão (status, evolução, observação, código) → **somente esta**.
- Campos de agenda (horário/duração/buffer/tag/local/link) → podem ser **esta** ou **futuras**.
- Trocar paciente do agendamento → **não propagar** (recomendação).

---

## 6) Pré-cadastro rápido do paciente
- Ao selecionar slot vago:
  - escolher paciente existente **OU**
  - pré-cadastrar paciente com **Nome completo + CPF**
- Após o pré-cadastro, permitir completar cadastro completo.

---

## 7) Cadastro do paciente (campos)
### 7.1 Identificação
- Nome de registro
- Nome social
- E-mail
- Data nascimento
- Sexo biológico
- Gênero
- Estado civil

### 7.2 Contato
- Celular
- Telefone fixo

### 7.3 Documentos
- CPF
- RG

### 7.4 Endereço (com CEP autofill)
- CEP
- Endereço
- Número
- Complemento
- Bairro
- Cidade
- Estado/UF

### 7.5 Menor de idade (condicional)
- Nome da mãe / profissão
- Nome do pai / profissão
- Nome responsável / CPF responsável

### 7.6 Outras informações
- Escolaridade
- Profissão
- Empresa
- Peso
- Altura
- Tipo sanguíneo

### 7.7 Origem/indicação
- Como ficou sabendo
- Quem indicou (nome e telefone)

### 7.8 Observações gerais
- Observações gerais devem aparecer no agendamento.

---

## 8) Cadastro do profissional
- Perfil básico + **CRP**.

---

## 9) WhatsApp (profissional)
- Botão WhatsApp no agendamento e na reserva.
- Menu “Falar com o paciente (assuntos diversos)” com templates:
  - Confirmação de atendimento
  - Confirmação presencial
  - Confirmação teleatendimento
  - Lembrete de atendimento
  - Aviso horário agendado
  - Aviso de reagendamento
  - Aviso horário cancelado
  - Não comparecimento
  - Pesquisa de satisfação
  - Aniversário

---

## 10) SaaS (trial + gating)
- Trial 10 dias (`trialEndsAt`).
- `planStatus`: `trial | active | past_due | expired`.
- Bloquear escritas quando `past_due/expired`.
- Leitura para paciente em caso de bloqueio: **a decidir** (mantido em aberto).

---

## 11) Fora do MVP (futuro)
- Pacotes/financeiro
- Teleatendimento in-app
- Multi-tenant avançado para revenda (billing completo)
