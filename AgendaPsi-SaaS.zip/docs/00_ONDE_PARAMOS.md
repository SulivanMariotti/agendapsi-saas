# Onde paramos — AgendaPsi (SaaS)

Atualização: **2026-03-02** (Portal do Paciente linkado ao Admin + cadastro completo do paciente no Profissional + isolamento de sessão do paciente)

## 1) Estado atual (resumo executivo)

### Fundamentos ✅
- Seed Firestore ok (tenant demo, paciente teste, série + ocorrências).
- Login Profissional com sessão server-side.
- Tenant isolation via `userTenantIndex/{uid}` (sem `collectionGroup`).

### Admin ✅
- Painéis existentes e operantes:
  - **Lembretes** (Admin é a fonte da verdade do módulo)
  - **Biblioteca/Artigos** (Admin é a fonte da verdade; paciente vê somente publicados)
  - **AgendaPsi**: schedule + códigos de ocorrência
- Fix aplicado: PATCH/DELETE de Biblioteca funcionando em dev (params robusto).

### Profissional ✅
- Agenda Dia/Semana/Mês + overlay com salvar unificado.
- Recorrência (plano), holds, conversão, reagendar/excluir por ocorrência vs futuras.
- WhatsApp no detalhe (MVP parcial).
- **Cadastro completo do paciente** no Profissional em `/profissional/pacientes/{patientId}`.

### Paciente ✅
- Portal `/paciente`:
  - Agenda informativa (próxima sessão + próximos)
  - “Seu cadastro” (subset do cadastro completo)
  - Contrato/Termo + aceite
  - Preferência “Ativar lembretes”
  - Biblioteca (linkada ao Admin; somente published)
  - Anotações do paciente (API; exclusão lógica)
- Sessão isolada do paciente via `patientApp` (evita conflito com profissional).

---

## 2) Próxima execução recomendada
Seguir o checklist em `docs/20_VALIDACAO_PORTAL_PACIENTE.md` (T01..T09) e ir corrigindo item a item (como já estamos fazendo).

Depois:
1) Admin: configurar `settings/patientPortal` (texto/versão do termo + flags)
2) Firestore Rules hardening (produção)
3) WhatsApp templates (Admin) + seleção no Profissional
