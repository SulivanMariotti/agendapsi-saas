# Onde paramos — AgendaPsi (SaaS)

Atualização: 2026-02-28

## Decisão reforçada: Separação do Lembrete Psi
- Lembrete Psi segue em produção na clínica (agenda.msgflow.app.br) como está.
- AgendaPsi é novo sistema separado (agendapsi.msgflow.app.br).
- Reuso é **apenas de código/UI/lógica**, nunca de base/dados/deploy.

## Estado atual (resumo)
- Seed Firestore OK (tenant `tn_JnA5yU`, série e ocorrências).
- Auth OK com sessão server-side e índice `userTenantIndex/{uid}`.
- Painel Profissional (/profissional) OK:
  - criar Hold/Agendar
  - duração por blocos (ocupa múltiplos slots)
  - status e cores
  - visual de card único para 2+ blocos

## Próximos passos
1) Configuração da agenda do profissional (slotInterval 30/45/60, buffer, almoço)
2) “Encontrar próximo horário disponível”
3) Iniciar Admin unificado (base Lembrete UI + módulos AgendaPsi)
4) Firestore Rules e hardening para produção
