# Painel do Profissional — UI (MVP)

Atualizado: 2026-02-28

## Rotas
- `/login`
- `/profissional` (Visão Dia atual)

## Funcionalidades atuais
- Lista de slots do dia conforme `settings/schedule.slotIntervalMin` (padrão 30).
- Criar Reserva/Hold:
  - Nome + Celular
  - Duração em blocos (1..4) com bloqueio do próximo slot
- Criar Agendamento (pré-cadastro):
  - Nome + CPF + Celular
  - Duração em blocos (1..4)
- Card único em sessões multi-bloco (slots seguintes são “continuação” e não clicáveis).
- Alterar Status (aplica no grupo inteiro).
- WhatsApp com templates por tenant.

## Próximas extensões
- Visões Semana e Mês.
- Navegação por granularidade (dia/semana/mês).
- Marcação da semana de aniversário.
