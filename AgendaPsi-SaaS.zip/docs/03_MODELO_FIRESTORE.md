# Modelo Firestore (detalhado) — AgendaPsi

Atualizado: **2026-03-02**

## 1) Regras gerais
- Todos os dados de negócio ficam em `tenants/{tenantId}/...`.
- Evitar `collectionGroup`.
- Preferir escrita/leituras atômicas via transações/batches no server (API routes).
- Evitar índices compostos:
  - agenda usa `slotKey`
  - logs usam subcoleções sem `where + orderBy` na mesma query

---

## 2) Coleções globais

### 2.1 `userTenantIndex/{uid}`
Índice para resolver tenant rapidamente no login (server-side).

Campos:
- `tenantId` (string)
- `role` (`admin` | `professional` | `owner`)
- `isActive` (boolean)
- `updatedAt` (timestamp)

---

## 3) Estrutura por tenant

### 3.1 `tenants/{tenantId}`
Campos:
- `name`
- `ownerUid`
- `timezone` (ex.: `America/Sao_Paulo`)
- `planStatus` (trial|active|past_due|expired)
- `trialEndsAt`
- `createdAt`

### 3.2 Membership — `tenants/{tenantId}/users/{uid}`
Campos:
- `uid`
- `role` (`admin` | `professional` | `owner`)
- `displayName`
- `email`
- `isActive`
- `createdAt`, `updatedAt`

### 3.3 Settings — `tenants/{tenantId}/settings/schedule`
Campos (MVP):
- `slotIntervalMin` (30|45|60)
- `bufferMin` (0..)
- `lunchEnabled` (bool) + `lunchStart`/`lunchEnd` (HH:MM)
- `days` (map por weekday):
  - `enabled` (bool)
  - `ranges`: lista de `{start,end}` em HH:MM
- `defaultBlocks` (int)  # duração padrão em múltiplos do slot
- `updatedAt`

### 3.4 Pacientes — `tenants/{tenantId}/patients/{patientId}`
Campos (MVP):
- `fullName`
- `mobile` (string)
- `email` (opcional)
- `birthMonthDay` (MM-DD, opcional)
- `notes` (observações gerais, opcional)
- `createdAt`, `updatedAt`
- (opcional) `activePlanTotalSessions` (int)  # quando houver plano ativo

#### 3.4.1 Evolução por sessão (prontuário)
`tenants/{tenantId}/patients/{patientId}/sessionEvolutions/{occurrenceId}`

Campos:
- `occurrenceId` (string)  # redundante (docId = occurrenceId)
- `seriesId` (string, opcional)
- `sessionStartAt` (timestamp)  # data/hora da sessão
- `text` (string)  # texto livre (sem código)
- `createdByUid` (string)
- `createdAt`, `updatedAt`

> Observação: excluir o agendamento libera horário, mas **não apaga** este documento.

#### 3.4.2 Ocorrências “extra” (espelho no paciente)
`tenants/{tenantId}/patients/{patientId}/occurrenceLogs/{logId}`

Campos:
- `patientId`
- `occurrenceId` (string)
- `seriesId` (string, opcional)
- `sessionStartAt` (timestamp)  # data/hora da sessão associada (quando existir)
- `codeId` (string)
- `code` (string)  # snapshot do código para facilitar relatórios
- `description` (string)
- `createdByUid`
- `createdAt`

### 3.5 Catálogo de códigos (Admin)
`tenants/{tenantId}/occurrenceCodes/{codeId}`

Campos:
- `code` (string, ex.: `OC01`)
- `description` (string)
- `isActive` (boolean)
- `createdAt`, `updatedAt`

### 3.6 Séries — `tenants/{tenantId}/appointmentSeries/{seriesId}`
Campos (MVP):
- `type` (`appointment` | `hold`)
- `repeatFrequency` (daily|weekly|biweekly|monthly)
- `plannedTotalSessions` (int)
- `startsAt` (timestamp)
- `endsAt` (timestamp, opcional)
- `patientId` (opcional, até converter hold)
- `createdAt`, `updatedAt`

### 3.7 Ocorrências — `tenants/{tenantId}/appointmentOccurrences/{occurrenceId}`
Campos (MVP):
- `seriesId` (string, opcional)
- `groupId` (string)  # agrupa blocos da mesma sessão
- `isBlock` (boolean)
- `blockIndex` (0..n-1)
- `startAt` (timestamp)
- `endAt` (timestamp)
- `slotKey` (`YYYY-MM-DD#HH:MM`)
- `isHold` (boolean)
- `status` (agendamento)  # hold não altera
- `sessionIndex` (int)
- `plannedTotalSessions` (int)
- `patientId` (string, opcional)
- `leadName`, `leadMobile` (para hold sem paciente)
- `patientSnapshot` (opcional, para render rápido): `{ fullName, mobile, notes, birthMonthDay }`
- `createdAt`, `updatedAt`

#### 3.7.1 Ocorrências “extra” (subcoleção na ocorrência)
`tenants/{tenantId}/appointmentOccurrences/{occurrenceId}/occurrenceLogs/{logId}`

Campos:
- `occurrenceId`
- `patientId`
- `seriesId` (opcional)
- `sessionStartAt` (timestamp)
- `codeId`, `code`
- `description`
- `createdByUid`
- `createdAt`

---

## 4) Operações críticas
### 4.1 Criar Agendar / Hold
- Respeitar schedule + buffer + multi-bloco.
- Criar `appointmentSeries` (quando recorrente) e materializar ocorrências.
- Operação atômica para recorrência (sem criação parcial).

### 4.2 Converter hold → agendamento
- Atualiza tipo na série e converte ocorrências existentes.
- Pode estender para novo total (materializa adicionais).
- Operação atômica (sem conflito).

### 4.3 Reagendar recorrente
- Perguntar: “Só esta” vs “Esta e futuras”.
- Operação atômica (conflito bloqueia).

### 4.4 Excluir
- Perguntar: “Só esta” vs “Esta e futuras”.
- Remove ocorrências da agenda (libera horário).
- Não apagar evolução (prontuário) nem ocorrência extra do paciente.

---

## 5) Índices
- Preferir não depender de índices compostos.
- Se for inevitável (futuro), registrar explicitamente em docs a necessidade do índice e o motivo.
