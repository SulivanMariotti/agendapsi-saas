# Reuso do Lembrete Psi como base (restrições)

Atualizado: **2026-03-02**

## Regra crítica
O Lembrete Psi (agenda.msgflow.app.br) permanece separado.
O AgendaPsi (agendapsi.msgflow.app.br) é outro projeto, outro Firebase, outras Rules.

## Reuso permitido (somente como base de implementação)
- Layout do Admin, componentes, tabela/filtros, toasts.
- Padrões de rotas/API e validação.
- Padrões de UI para agenda (se aplicável).

## Reuso proibido
- Firebase Project do Lembrete
- Firestore/coleções/rules do Lembrete
- Deploy/URL do Lembrete
- Claims/políticas do Lembrete

## Observação sobre o menu “Lembretes” no Admin do AgendaPsi
- É apenas estrutura de navegação (placeholder).
- Não deve acessar dados do Firebase do Lembrete Psi.
