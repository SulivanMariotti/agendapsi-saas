# Backlog consolidado — AgendaPsi (SaaS)

Atualizado: **2026-03-02**

## Como ler este backlog
- Etiquetas: **[MVP]** e **[PÓS-MVP]**
- Status: **Pronto / Em andamento / Pendente**
- Riscos: **LGPD / Segurança / UX / Performance**

---

## ÉPICO A — Fundação do SaaS (separação, auth, tenant)
- **[MVP]** Separação total do Lembrete Psi → **Pronto**
- **[MVP]** Auth + sessão server-side (profissional) → **Pronto**
- **[MVP]** Isolamento por tenant via `userTenantIndex/{uid}` → **Pronto**
- **[PÓS-MVP]** Hardening completo de Rules (produção) → **Pendente** (Segurança/LGPD)

---

## ÉPICO B — Admin (desktop)
- **[MVP]** Schedule (ranges, almoço, buffer, slot interval) → **Pronto**
- **[MVP]** Menus + Submenus (Dashboard default) → **Pronto**
- **[MVP]** Catálogo de Códigos de Ocorrência (para “registro extra”) → **Pronto**
- **[PÓS-MVP]** Gestão de profissionais/pacientes avançada → **Pendente**

---

## ÉPICO C — Agenda do Profissional (Dia/Semana/Mês)
- **[MVP]** Dia/Semana/Mês com navegação por granularidade → **Pronto**
- **[MVP]** Status manual (Agendado, Confirmado, Finalizado, Não comparece, Cancelado, Reagendado) + cores → **Pronto**
- **[MVP]** Holds/Reservas com `isHold=true` e status travado → **Pronto**
- **[MVP]** Multi-bloco + buffer → **Pronto**
- **[MVP]** Próximos horários (3 sugestões) → **Pronto**
- **[MVP]** Mês: clique em área livre do dia abre Agendar/Reservar → **Pronto**
- **[MVP]** Reagendar recorrente (só esta vs esta e futuras) + week picker → **Pronto**
- **[MVP]** Excluir (só esta vs esta e futuras) → **Pronto**
- **[PÓS-MVP]** Ajustes finos de UX: abas de “Registros do paciente” no detalhe + detalhe em overlay + salvar unificado → **Pronto** (UX)

---

## ÉPICO D — Cadastro e Painel do Paciente
- **[MVP]** Cadastro do paciente (completo + pré-cadastro rápido) → **Pendente**
- **[MVP]** Painel do paciente (sem CTA cancelar/remarcar) → **Pendente** (UX/Produto)
- **[PÓS-MVP]** Semana de aniversário (destaque) → **Pendente**

---

## ÉPICO E — Registros clínicos (Evolução vs Ocorrência extra)
- **[MVP]** Evolução por sessão (texto livre) armazenada no paciente (ref pela sessão) → **Pronto**
- **[MVP]** Ocorrência “extra” com código + descrição → **Pronto**
- **[MVP]** Histórico recente do paciente (evoluções e ocorrências) → **Em andamento** (UX de apresentação)
- **[PÓS-MVP]** Relatório por código de ocorrência (filtros/contagem/export) → **Pendente** (seu pedido)

---

## ÉPICO F — WhatsApp
- **[MVP]** Botão WhatsApp no detalhe do agendamento/hold → **Pronto**
- **[MVP]** Templates WhatsApp (Admin) + uso no Profissional → **Pendente**
