# AgendaPsi — Arquivo para iniciar um novo chat (HANDOFF)

Data: 2026-02-28

## 1) Objetivo do projeto
Construir o **AgendaPsi (SaaS)** em **Next.js (App Router) + Firebase (Firestore/Auth/Storage/FCM)**, em subdomínio separado: **agendapsi.msgflow.app.br**, com foco na rotina do profissional e constância do cuidado.

O sistema terá 3 painéis:
- **Admin** (desktop completo)
- **Profissional** (agenda otimizada para mobile e desktop)
- **Paciente** (sem CTA de cancelar/remarcar; foco em constância)

## 2) Separação total do Lembrete Psi (decisão crítica)
O **Lembrete Psi** continuará sendo usado **na clínica** “como está”, rodando em **agenda.msgflow.app.br**, com seu Firebase/Firestore atual.

O **AgendaPsi é um sistema novo e separado**, com:
- projeto Firebase/Firestore próprios
- regras e coleções próprias
- subdomínio próprio (**agendapsi.msgflow.app.br**)

### O que reaproveitamos do Lembrete Psi
✅ **Somente código/UI/lógica/padrões** (como base de implementação), por exemplo:
- componentes de UI do Admin (layout, tabelas, filtros, toasts, navegação)
- padrões de endpoints e validação
- base de push/notificações (quando for integrar lembretes)

### O que NÃO reaproveitamos do Lembrete Psi
❌ Não compartilhamos:
- o mesmo deploy/URL
- o mesmo Firebase Project
- a mesma base Firestore/coleções/rules
- custom claims e políticas de segurança do Lembrete (AgendaPsi terá as suas)

## 3) Como o Admin do AgendaPsi fica “Admin do Lembrete + Admin da Agenda”
No **AgendaPsi**, o painel **Admin** será **unificado** em termos de UX/código base:
- reutilizamos o *template* do Admin do Lembrete Psi (UI + componentes)
- adicionamos módulos do AgendaPsi (tenants, profissionais, pacientes, agenda, códigos, templates, etc.)

Mas isso ocorre **dentro do AgendaPsi**, com dados próprios.  
O Lembrete Psi da clínica permanece independente.

## 4) Onde paramos (estado atual)
- Seed do Firestore funcionando (tenant `tn_JnA5yU`, paciente teste, série + ocorrências).
- Login do profissional funcionando com sessão server-side.
- Isolamento por tenant via índice `userTenantIndex/{uid}` (sem `collectionGroup`).
- Painel `/profissional` com:
  - visão Dia
  - criar Reserva/Hold
  - criar Agendamento (pré-cadastro)
  - duração por blocos (2+ slots)
  - status e cores
  - visual de card único (continuação bloqueada)
  - WhatsApp templates

## 5) Modelo de dados (essencial)
Coleções principais (por tenant):
- `tenants/{tenantId}`
- `tenants/{tenantId}/users/{uid}` (membership)
- `userTenantIndex/{uid}` (índice global para resolver tenant no login)
- `tenants/{tenantId}/patients/{patientId}`
- `tenants/{tenantId}/appointmentSeries/{seriesId}`
- `tenants/{tenantId}/appointmentOccurrences/{occurrenceId}`
- `tenants/{tenantId}/occurrenceCodes/{codeId}`
- `tenants/{tenantId}/whatsappTemplates/{templateId}`
- `tenants/{tenantId}/settings/schedule`

## 6) Como rodar localmente
1. `npm install`
2. `.env.local` deve ter:
   - `SERVICE_ACCOUNT_JSON_PATH=C:\secrets\agendapsi-admin.json`
   - `NEXT_PUBLIC_FIREBASE_*` (web config do projeto `agendapsi-saas`)
3. `npm run dev`
4. Acessar: `http://localhost:3000/login` → login → `/profissional`

## 7) Como validar (checklist)
- Login funciona e redireciona para `/profissional`
- Criar Reserva de 2 blocos ocupa o slot seguinte (continuação bloqueada)
- Alterar status aplica no grupo inteiro (2 blocos)
- No Firestore existem:
  - `userTenantIndex/{uid}` com `tenantId/role/isActive`

## 8) O que subir no próximo chat
Obrigatório:
1. **ZIP do projeto atual do AgendaPsi** (`agendapsi-saas.zip`) **sem** `node_modules/` e sem `.next/`
2. **Este arquivo** (ou o zip de docs atualizado)

Opcional (somente se o passo for portar/espelhar telas do Admin/Paciente do Lembrete Psi):
3. `lembrete-psi.zip` (somente como **referência** de código/UI — não como base de dados/produção)

## 9) Próximos passos sugeridos
- Tela/configuração da agenda do profissional (slotInterval 30/45/60, buffer, almoço)
- “Encontrar próximo horário disponível”
- Iniciar painel Admin unificado (base do Admin do Lembrete + módulos do AgendaPsi)
- Regras Firestore (tenant isolation) e hardening de produção
