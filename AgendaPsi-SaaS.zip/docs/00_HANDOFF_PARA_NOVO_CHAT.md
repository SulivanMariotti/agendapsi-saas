# AgendaPsi — HANDOFF para novo chat

Data: **2026-03-03**  
Timezone: **America/Sao_Paulo**  
Objetivo deste arquivo: permitir retomar o desenvolvimento **exatamente de onde paramos** (sem depender do histórico do chat).

---

## 1) Identidade do projeto

- Projeto: **AgendaPsi (SaaS)**
- Stack: **Next.js (App Router) + Firebase (Firestore/Auth/Storage)** (+ FCM quando aplicável)
- Domínio: **agendapsi.msgflow.app.br**
- Regra crítica: **separação total do Lembrete Psi** (deploy/Firebase/dados/rules separados). Reuso permitido apenas de **código/UI/padrões**.

---

## 2) Objetivo do produto

Agenda clínica com foco na rotina do profissional, organização e constância do cuidado.

Painéis:
1) **Admin** (desktop completo)
2) **Profissional** (mobile + desktop)
3) **Paciente** (portal informativo **sem CTA de cancelar/remarcar**)

Premissas oficiais:
- **Sem importação por CSV** (fonte da verdade é o que o Profissional cadastra e agenda).
- Portal do paciente **sem Firestore no client** (tudo via **APIs server-side**).
- Sessões isoladas no mesmo navegador: paciente usa **Firebase App secundário** (`patientApp`).

---

## 3) Estado atual (onde paramos)

### 3.1 Fundamentos ✅
- Seed do Firestore funcionando (tenant demo, paciente teste, séries + ocorrências).
- Login do profissional com **sessão server-side**.
- Isolamento por tenant via `userTenantIndex/{uid}` (sem `collectionGroup`).

### 3.2 Admin ✅ (com extensões nesta conversa)
Menus principais:
- Dashboard
- Lembretes (Admin é fonte da verdade do módulo)
- Biblioteca/Artigos (Admin é fonte da verdade do módulo)
- AgendaPsi → Agenda do Profissional + Códigos de Ocorrência + **Portal do Paciente (settings)** + **Templates WhatsApp**
- **SaaS → Tenants** (Super Admin)

Features Admin:
- `tenants/{tenantId}/settings/schedule` configurável.
- `tenants/{tenantId}/occurrenceCodes/{codeId}` catálogo.
- **Portal do Paciente por tenant** em `tenants/{tenantId}/settings/patientPortal`:
  - `termsText`, `termsVersion`
  - flags: `libraryEnabled`, `notesEnabled`, `remindersEnabled`
- **Templates WhatsApp por tenant** em `tenants/{tenantId}/whatsappTemplates` (CRUD).

### 3.3 Profissional (/profissional) ✅
- Visões: Dia / Semana / Mês
- Overlay (X para fechar, chips no header, abas clínicas)
- Salvar unificado (status + evolução + ocorrência extra)
- Recorrência (plano 1..30), holds e conversão
- Reagendar / Excluir: “só esta” vs “esta e futuras”
- WhatsApp no detalhe:
  - agora suporta **templates selecionáveis** (Admin gerencia; Profissional escolhe).

### 3.4 Paciente (/paciente) ✅
Módulos MVP:
- Agenda (informativo)
- Seu cadastro (subset)
- Contrato/Termo (visualizar + aceitar)
- Ativar lembretes (opt-in/opt-out)
- Biblioteca (somente publicados do Admin)
- Anotações do paciente (criar/listar/remover com exclusão lógica)

Regras do portal:
- Sem CTA de cancelar/remarcar
- Sem Firestore no client (APIs server-side)
- Auth isolado (`patientApp`)

Correções recentes relevantes:
- Anotações agora usam `getAuth(patientApp)` (evita `currentUser=null`)
- Toggle de lembretes passou a refletir o valor **efetivo** do paciente corretamente
- Rotas do portal agora aplicam `enforceSameOrigin` e `rateLimit` corretamente (retorno early quando `ok=false`)
- **Badge DEV** opcional no portal mostrando `tenantId` ativo (evita confusão ao configurar settings no Admin)

---

## 4) SaaS (Super Admin) — implementado nesta conversa ✅

### 4.1 Tenants (criar/listar/suspender)
- UI: **Admin → SaaS → Tenants**
- API:
  - `GET /api/admin/saas/tenants?q=...`
  - `POST /api/admin/saas/tenants { name }`
  - `PATCH /api/admin/saas/tenants { tenantId, status }`

### 4.2 Vincular Owner ao tenant
- API: `POST /api/admin/saas/tenants/owner { tenantId, email|uid }`
- Cria membership: `tenants/{tenantId}/users/{uid}` com `role="owner"`
- Atualiza índice: `userTenantIndex/{uid}`

### 4.3 Suspensão com efeito real (bloqueio)
Quando `tenants/{tenantId}.status != "active"`:
- Portal do paciente (`/api/paciente/*`) retorna **403 TENANT_SUSPENDED**
- Profissional bloqueia sessão (`/api/auth/session`) com **403 TENANT_SUSPENDED**
- UX amigável no login do profissional e no portal do paciente (tela/alerta).

### 4.4 Auditoria mínima
- Ações de SaaS registradas em `audit_logs` (ex.: `TENANT_CREATE`, `TENANT_STATUS_CHANGE`, `TENANT_OWNER_LINK`).

---

## 5) Modelo de dados (essencial)

Por tenant:
- `tenants/{tenantId}`
- `tenants/{tenantId}/users/{uid}` (membership)
- `tenants/{tenantId}/patients/{patientId}`
- `tenants/{tenantId}/appointmentSeries/{seriesId}`
- `tenants/{tenantId}/appointmentOccurrences/{occurrenceId}` (hold via `isHold`)
- `tenants/{tenantId}/occurrenceCodes/{codeId}`
- `tenants/{tenantId}/settings/schedule`
- `tenants/{tenantId}/settings/patientPortal`
- `tenants/{tenantId}/whatsappTemplates/{templateId}`

Índice global:
- `userTenantIndex/{uid}`

Subcoleções clínicas:
- `patients/{patientId}/sessionEvolutions/{occurrenceId}` (docId=occurrenceId)
- `appointmentOccurrences/{occurrenceId}/occurrenceLogs/{logId}` + espelho em `patients/{patientId}/occurrenceLogs/{logId}`

Portal do paciente:
- Preferências/aceite no doc do paciente: `patients/{patientId}.portal.*`
- Anotações: `patients/{patientId}/patientNotes/{noteId}` (exclusão lógica)
- Biblioteca: `library_articles/{articleId}` (global; paciente vê só published via API)

---

## 6) Segurança e permissões (alto nível)

Papéis:
- **Super Admin SaaS**: claim `role="admin"` (global)
- **Admin/Owner do tenant**: membership em `tenants/{tenantId}/users/{uid}` (`role="owner"` / `admin`)
- **Profissional**: membership (`role="professional"`)
- **Paciente**: portal via API; token/claims carregam `tenantId` e `patientId`

Regras importantes:
- Princípio do menor privilégio
- Tenant isolation por path `tenants/{tenantId}/...`
- Portal do paciente permanece via API (sem listener Firestore no client)

---

## 7) Variáveis de ambiente (relevantes)

Além de `SERVICE_ACCOUNT_JSON_PATH`, `NEXT_PUBLIC_FIREBASE_*`, `ADMIN_PASSWORD`:
- `ENABLE_PATIENT_DEV_TOKEN=true` (somente dev)
- `NEXT_PUBLIC_ENABLE_PATIENT_DEV_DEMO=true` (somente dev)
- `PATIENT_ACCESS_CODE_TTL_MIN=15`

---

## 8) Como rodar localmente

1) `npm install`
2) `.env.local` com as variáveis do projeto
3) `npm run dev`
4) Acessos:
   - `http://localhost:3000/login` → profissional → `/profissional`
   - `http://localhost:3000/admin` → admin
   - `http://localhost:3000/paciente` → portal do paciente

---

## 9) Checklist de validação (rápido)

### Portal do Paciente
- [ ] `/paciente` abre sem `permission-denied`
- [ ] Contrato: pendente → aceitar → fica OK; bump `termsVersion` volta a pendente
- [ ] Lembretes: toggle persiste após F5
- [ ] Biblioteca: só published
- [ ] Anotações: criar/listar/remover funciona

### Admin (AgendaPsi)
- [ ] Portal do Paciente (settings): salvar `termsText/termsVersion/flags` em `tenants/{tenantId}/settings/patientPortal`
- [ ] Templates WhatsApp: CRUD em `tenants/{tenantId}/whatsappTemplates`

### SaaS (Super Admin)
- [ ] Admin → SaaS → Tenants lista/cria/suspende/reativa
- [ ] Vincular Owner (email/uid existente no Auth) cria membership + userTenantIndex
- [ ] Suspender tenant bloqueia: paciente (`/api/paciente/*`) e profissional (`/api/auth/session`)
- [ ] UX amigável aparece ao bloquear

### Profissional
- [ ] No detalhe do agendamento: selecionar template e abrir WhatsApp com placeholders

---

## 10) Próximos passos sugeridos (ordem recomendada)

1) **Tenant Admin (Owner)**: expor telas de Templates WhatsApp e Patient Portal settings para `role=owner/admin` (sem depender do Super Admin).
2) **Convite de Owner** (Pós-MVP ou MVP+): quando email não existir no Auth → criar convite com token e fluxo de cadastro.
3) **Billing/Planos** (Pós-MVP): limites por tenant + feature flags por plano.
4) **Auditoria avançada** (Pós-MVP): filtros, retenção, export seguro.
5) Revisão final de Rules + API rate limit (cobrir endpoints restantes).

---

## 11) Para iniciar um novo chat amanhã (obrigatório anexar)
1) **ZIP do projeto atual** (sem `node_modules/` e sem `.next/`)
2) Este arquivo: `docs/00_HANDOFF_PARA_NOVO_CHAT.md`

Opcional:
- prints/vídeo curto do portal
- lembrete-psi.zip apenas como referência de UI (nunca base de dados)



---

## 12) Documentos de apoio

- `docs/21_HARDENING_PORTAL_API_SECURITY.md`
- `docs/22_SETTINGS_PATIENT_PORTAL.md`
- `docs/23_HARDENING_FINAL_RULES_PORTAL.md`
- `docs/24_DEV_BADGE_TENANT.md`
- `docs/26_SUPER_ADMIN_SAAS_TENANTS.md`
- `docs/27_SUPER_ADMIN_SAAS_TENANT_SUSPENSION.md`
- `docs/28_UX_TENANT_SUSPENDED.md`
- `docs/29_WHATSAPP_TEMPLATES.md`
- `docs/31_PATCHES_ZIPS_APLICADOS.md`
- Referências base (v0):
  - `docs/01_REFERENCIA_MODELO_DADOS_v0.md`
  - `docs/02_REFERENCIA_SEGURANCA_PERMISSOES_v0.md`
