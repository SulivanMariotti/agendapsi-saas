import ProfessionalDayViewClient from "@/components/Professional/ProfessionalDayViewClient";
import { getProfessionalDayData, resolveIsoDate } from "@/lib/server/agendapsiData";
import { requireProfessionalSession } from "@/lib/server/requireProfessional";

export const dynamic = "force-dynamic";

export default async function ProfissionalPage({ searchParams }) {
  const next = `/login?next=${encodeURIComponent("/profissional")}`;
  const session = await requireProfessionalSession({ redirectTo: next });
  const tenantId = session.tenantId;
  // Some Next.js versions provide searchParams as a Promise.
  const sp = await Promise.resolve(searchParams);
  const isoDate = resolveIsoDate(sp);

  const data = await getProfessionalDayData({ tenantId, isoDate });

  return (
    <div className="min-h-[100dvh] bg-slate-50">
      <ProfessionalDayViewClient initialData={data} />
    </div>
  );
}
